<?php
class Server {
	public $sp_params;
	public function test() {
		return 'Hello!';
	}
}