<?php
function hello(){
	$answer = 'hello';
	return $answer;
}
function array_ret(){
	$answer = array('Robert', 'Ann', 'Michael');
	return $answer;
}
function array_multi(){
	$answer = array('Smth', array('Robert', 'Ann'));
	return $answer;
}