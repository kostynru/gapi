<?php

// Getting API - Realise Version 
// Copyright (C) 2012 Shelko Konstantin
// ��� ����� �� ������ ���� ����������� ����� �����������.
// �� �������� �������������� ���������� �� �������:
// kostynru@ymail.com
// vk.com/shelko_kostya
// vk.com/gettingapi
// -----------------------------------------------------------
// It's main file of Getting API. Please don't edit it manualy.
// You may only edit database connection options.
// -----------------------------------------------------------
// ��� ������� ���� Getting API. ����������, �� ������������
// ��� �������. �� ������ �������� ������ ��������� �����������
// � ���� ������. ��� ��������� �������������

//��������� ����������� � ���� ������
mysql_connect('localhost', 'root', '');
mysql_select_db('api');
//����� �������� ����������� � ���� ������
//Warning!! Hardcode is beginig here!
$params = $_GET;
$spaceandmethod = explode(".", $params['q']);
$space = $spaceandmethod[0];
$method = $spaceandmethod[1];
function error_to_xml($error_string = 'Unknown error has been appeared', $type = 'xml'){
	if(!$type == null or !empty($type)){
		if($type == 'xml'){
			header('Content-type: application/xml');
			$xml = <<< EOXML
<?xml version="1.0" encoding="utf-8" ?>
	<api type="gettingapi">
		<error>
			<answer>$error_string</answer>
		</error>
	</api>
EOXML;
			return trim($xml);
		} elseif($type == 'json'){
			header('Content-type: application/json');
			$json = array('error' => $error_string);
			$json = json_encode($json);
			return $json;
		} else {
			echo 'Wrong type of answer';
		}
	} else {
		header('Content-type: application/xml');
		$xml = <<< EOXML
<?xml version="1.0" encoding="utf-8" ?>
	<api type="gettingapi">
		<error>
			<answer>$error_string</answer>
		</error>
	</api>
EOXML;
		return trim($xml);
	}
}
if($params['q'] == 'auth'){
	$app_key = $params['app_key'];
	$app_id = $params['app_id'];
	$response_type = $params['response'];
	if($app_key == null or $app_id == null or $response_type == null){
		echo error_to_xml('Wrong count of params for auth', $response_type);
		exit;
	}
	if(!is_numeric($app_id)){
		echo error_to_xml('Invalid application id', $response_type);
		exit;
	}
	$query = "SELECT private_key FROM apps_access WHERE app_id = '$app_id'";
	$result = mysql_query($query) or die(mysql_error());
	while($row = mysql_fetch_row($result)){
		$app_secret = $row[0];
	}
	if($app_key == $app_secret){
		$app_token = hash('md2', str_shuffle(strrev(str_rot13(md5($app_secret.time())))));
		$time = time();
		switch($response_type) {
			case 'xml':
				$response = 1;
				break;
			case 'json':
				$response = 2;
				break;
			default:
				$response = 1;
			}
		$query = "INSERT INTO apps_sessions(app_id, datastamp, app_token, response_type) VALUES
		('$app_id', '$time', '$app_token', '$response')";
		mysql_query($query) or die(mysql_error());
		if($response_type == 'xml'){
			header('Content-type: application/xml');
			echo "<?xml version=\"1.0\" encoding=\"utf-8\" ?>
			<api type=\"gettingapi\">
				<$space>
					<answer>$app_token</answer>
				</$space>
			</api>";
			exit;
		} else {
			header('Content-type: application/json');
			echo ' { "token" : "'.$app_token.'" }';
			exit;
		}
	} else {
		error_to_xml('Invalid application id or secret key', $response_type);
		exit;
	}
} else {
	$l_space = ucfirst($space);
	if(file_exists("spaces/$space.php")){
		include_once '/spaces/'.$space.'.php';
		$method_ex = array($l_space, $method);
		if(!is_callable($method_ex, true) or !method_exists($l_space, $method)){
			echo error_to_xml('Required method does not exist', $response_type);
			exit;
		}
		$token = $_GET['token'];
		$query = "SELECT * FROM apps_sessions WHERE app_token = '$token'";
		$result = mysql_query($query) or die(mysql_error());
		if($result == false){
			echo error_to_xml('The key has expired or session has been closed', $response_type);
			exit;
		}
		while($row = mysql_fetch_assoc($result)){
			$response = $row['response_type'];
			$date = $row['datastamp'];
			$app_id = $row['app_id'];
		}
		switch($response){
			case '1':
				$err_resp = 'xml';
				break;
			case '2':
				$err_resp = 'json';
				break;
			default:
				$err_resp = 'xml';
		}
		$now_date = time();
		if($now_date - $date > 3600){
			$query = "DELETE FROM apps_sessions WHERE app_id = '$app_id'";
			mysql_query($query) or die(mysql_error());
			echo error_to_xml('The key has expired or session has been closed', $err_resp);
			exit;
		}
		if (class_exists($space)){
			$process = new $l_space;
			$answer = $process->$method($params);
		} else {
			$answer = $method();
		}
		if(is_array($answer)){
			if($response == 1){
				header('Content-type: application/xml');
				echo '<?xml version="1.0" encoding="utf-8" ?>
							<api type="gettingapi">
							<'.$space.'>
								<'.$method.'>
								<answer>';
				function multiarray_to_xml(array $arr) {
					foreach($arr as $key => $value){
						if(is_array($value)){
							echo "<arr result=\"$key\">";
							multiarray_to_xml($value);
							echo "</arr>";
						} else {
							echo "<$key>$value</$key>";
						}
					}
					return null;
				}		
				multiarray_to_xml($answer);
				echo '
								</answer>
						</'.$method.'>
					</'.$space.'>	
				</api>';
				exit;
			} else {
				header('Content-type: application/json');
				echo json_encode($answer);
				exit;
			}
		} else {
			if($response == 1){
				header('Content-type: application/xml');
				echo '<?xml version="1.0" encoding="utf-8" ?>
						<api type="gettingapi">
						<'.$space.'>
							<'.$method.'>
							<answer>'.$answer.'</answer>
							</'.$method.'>
						</'.$space.'>	
						</api>';
				exit;
			} elseif ($response == 2){
				header('Content-type: application/json');
					echo ' { "answer" : "'.$answer.'" }';
					exit;
			}
		}
        } else {
			echo error_to_xml('Required space does not exist', $err_resp);
			exit;
		}
}

