/*
Navicat MySQL Data Transfer

Source Server         : api
Source Server Version : 50525
Source Host           : localhost:3306
Source Database       : api

Target Server Type    : MYSQL
Target Server Version : 50525
File Encoding         : 65001

Date: 2012-11-27 11:37:42
*/

SET FOREIGN_KEY_CHECKS=0;
-- ----------------------------
-- Table structure for `api_info`
-- ----------------------------
DROP TABLE IF EXISTS `api_info`;
CREATE TABLE `api_info` (
  `api_ver` varchar(250) NOT NULL,
  `api_creator` varchar(250) NOT NULL,
  `api_owner` varchar(250) NOT NULL,
  `copyrights` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of api_info
-- ----------------------------
INSERT INTO `api_info` VALUES ('1.0.0a', 'Shelko Konstantin', '', '2012');

-- ----------------------------
-- Table structure for `apps`
-- ----------------------------
DROP TABLE IF EXISTS `apps`;
CREATE TABLE `apps` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(250) NOT NULL,
  `url` varchar(250) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of apps
-- ----------------------------

-- ----------------------------
-- Table structure for `apps_access`
-- ----------------------------
DROP TABLE IF EXISTS `apps_access`;
CREATE TABLE `apps_access` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `public_key` varchar(250) NOT NULL,
  `private_key` varchar(250) NOT NULL,
  PRIMARY KEY (`id`,`public_key`,`private_key`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of apps_access
-- ----------------------------

-- ----------------------------
-- Table structure for `apps_response_type`
-- ----------------------------
DROP TABLE IF EXISTS `apps_response_type`;
CREATE TABLE `apps_response_type` (
  `id` int(11) NOT NULL,
  `response_type` varchar(10) NOT NULL,
  PRIMARY KEY (`id`,`response_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of apps_response_type
-- ----------------------------
INSERT INTO `apps_response_type` VALUES ('1', 'xml');
INSERT INTO `apps_response_type` VALUES ('2', 'json');

-- ----------------------------
-- Table structure for `apps_sessions`
-- ----------------------------
DROP TABLE IF EXISTS `apps_sessions`;
CREATE TABLE `apps_sessions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `app_id` int(11) NOT NULL,
  `datastamp` varchar(250) NOT NULL DEFAULT '',
  `app_token` varchar(250) NOT NULL,
  `response_type` int(1) NOT NULL,
  PRIMARY KEY (`id`,`app_id`,`app_token`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of apps_sessions
-- ----------------------------
